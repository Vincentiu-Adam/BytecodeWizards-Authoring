/********************************************************************************
** Form generated from reading UI file 'authoringwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUTHORINGWINDOW_H
#define UI_AUTHORINGWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "canvaswidget.h"

QT_BEGIN_NAMESPACE

class Ui_AuthoringWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QPushButton *setLiteral;
    QPushButton *getHealth;
    QPushButton *setHealth;
    QPushButton *getWisdom;
    QPushButton *setWisdom;
    QPushButton *add;
    QPushButton *subtract;
    QPushButton *multiply;
    QPushButton *divide;
    QPushButton *playAnim;
    QPushButton *playVFX;
    QPushButton *generate;
    QSpacerItem *verticalSpacer;
    CanvasWidget *canvas;
    QStatusBar *statusbar;
    QMenuBar *menubar;

    void setupUi(QMainWindow *AuthoringWindow)
    {
        if (AuthoringWindow->objectName().isEmpty())
            AuthoringWindow->setObjectName("AuthoringWindow");
        AuthoringWindow->resize(800, 600);
        centralwidget = new QWidget(AuthoringWindow);
        centralwidget->setObjectName("centralwidget");
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setSpacing(10);
        horizontalLayout->setObjectName("horizontalLayout");
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(7);
        verticalLayout->setObjectName("verticalLayout");
        verticalLayout->setContentsMargins(0, -1, -1, -1);
        setLiteral = new QPushButton(centralwidget);
        setLiteral->setObjectName("setLiteral");

        verticalLayout->addWidget(setLiteral);

        getHealth = new QPushButton(centralwidget);
        getHealth->setObjectName("getHealth");

        verticalLayout->addWidget(getHealth);

        setHealth = new QPushButton(centralwidget);
        setHealth->setObjectName("setHealth");

        verticalLayout->addWidget(setHealth);

        getWisdom = new QPushButton(centralwidget);
        getWisdom->setObjectName("getWisdom");

        verticalLayout->addWidget(getWisdom);

        setWisdom = new QPushButton(centralwidget);
        setWisdom->setObjectName("setWisdom");

        verticalLayout->addWidget(setWisdom);

        add = new QPushButton(centralwidget);
        add->setObjectName("add");

        verticalLayout->addWidget(add);

        subtract = new QPushButton(centralwidget);
        subtract->setObjectName("subtract");

        verticalLayout->addWidget(subtract);

        multiply = new QPushButton(centralwidget);
        multiply->setObjectName("multiply");

        verticalLayout->addWidget(multiply);

        divide = new QPushButton(centralwidget);
        divide->setObjectName("divide");

        verticalLayout->addWidget(divide);

        playAnim = new QPushButton(centralwidget);
        playAnim->setObjectName("playAnim");

        verticalLayout->addWidget(playAnim);

        playVFX = new QPushButton(centralwidget);
        playVFX->setObjectName("playVFX");

        verticalLayout->addWidget(playVFX);

        generate = new QPushButton(centralwidget);
        generate->setObjectName("generate");
        generate->setAutoFillBackground(false);
        generate->setStyleSheet(QString::fromUtf8("color:black;\n"
"background:red"));
        generate->setFlat(false);

        verticalLayout->addWidget(generate);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout);

        canvas = new CanvasWidget(centralwidget);
        canvas->setObjectName("canvas");
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(canvas->sizePolicy().hasHeightForWidth());
        canvas->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(canvas);

        AuthoringWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(AuthoringWindow);
        statusbar->setObjectName("statusbar");
        AuthoringWindow->setStatusBar(statusbar);
        menubar = new QMenuBar(AuthoringWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 25));
        AuthoringWindow->setMenuBar(menubar);

        retranslateUi(AuthoringWindow);

        QMetaObject::connectSlotsByName(AuthoringWindow);
    } // setupUi

    void retranslateUi(QMainWindow *AuthoringWindow)
    {
        AuthoringWindow->setWindowTitle(QCoreApplication::translate("AuthoringWindow", "AuthoringWindow", nullptr));
        setLiteral->setText(QCoreApplication::translate("AuthoringWindow", "Set Literal", nullptr));
        getHealth->setText(QCoreApplication::translate("AuthoringWindow", "Get Health", nullptr));
        setHealth->setText(QCoreApplication::translate("AuthoringWindow", "Set Health", nullptr));
        getWisdom->setText(QCoreApplication::translate("AuthoringWindow", "Get Wisdom", nullptr));
        setWisdom->setText(QCoreApplication::translate("AuthoringWindow", "Set Wisdom", nullptr));
        add->setText(QCoreApplication::translate("AuthoringWindow", "Add", nullptr));
        subtract->setText(QCoreApplication::translate("AuthoringWindow", "Subtract", nullptr));
        multiply->setText(QCoreApplication::translate("AuthoringWindow", "Multiply", nullptr));
        divide->setText(QCoreApplication::translate("AuthoringWindow", "Divide", nullptr));
        playAnim->setText(QCoreApplication::translate("AuthoringWindow", "Play Anim", nullptr));
        playVFX->setText(QCoreApplication::translate("AuthoringWindow", "Play VFX", nullptr));
        generate->setText(QCoreApplication::translate("AuthoringWindow", "Generate", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AuthoringWindow: public Ui_AuthoringWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUTHORINGWINDOW_H
