/****************************************************************************
** Meta object code from reading C++ file 'canvaswidget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../BytecodeWizardsAuthoring/canvaswidget.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'canvaswidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_CanvasWidget_t {
    uint offsetsAndSizes[26];
    char stringdata0[13];
    char stringdata1[30];
    char stringdata2[1];
    char stringdata3[30];
    char stringdata4[30];
    char stringdata5[30];
    char stringdata6[31];
    char stringdata7[24];
    char stringdata8[29];
    char stringdata9[29];
    char stringdata10[27];
    char stringdata11[29];
    char stringdata12[28];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CanvasWidget_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CanvasWidget_t qt_meta_stringdata_CanvasWidget = {
    {
        QT_MOC_LITERAL(0, 12),  // "CanvasWidget"
        QT_MOC_LITERAL(13, 29),  // "onGetHealthInstructionClicked"
        QT_MOC_LITERAL(43, 0),  // ""
        QT_MOC_LITERAL(44, 29),  // "onSetHealthInstructionClicked"
        QT_MOC_LITERAL(74, 29),  // "onGetWisdomInstructionClicked"
        QT_MOC_LITERAL(104, 29),  // "onSetWisdomInstructionClicked"
        QT_MOC_LITERAL(134, 30),  // "onSetLiteralInstructionClicked"
        QT_MOC_LITERAL(165, 23),  // "onAddInstructionClicked"
        QT_MOC_LITERAL(189, 28),  // "onSubtractInstructionClicked"
        QT_MOC_LITERAL(218, 28),  // "onMultiplyInstructionClicked"
        QT_MOC_LITERAL(247, 26),  // "onDivideInstructionClicked"
        QT_MOC_LITERAL(274, 28),  // "onPlayAnimInstructionClicked"
        QT_MOC_LITERAL(303, 27)   // "onPlayVFXInstructionClicked"
    },
    "CanvasWidget",
    "onGetHealthInstructionClicked",
    "",
    "onSetHealthInstructionClicked",
    "onGetWisdomInstructionClicked",
    "onSetWisdomInstructionClicked",
    "onSetLiteralInstructionClicked",
    "onAddInstructionClicked",
    "onSubtractInstructionClicked",
    "onMultiplyInstructionClicked",
    "onDivideInstructionClicked",
    "onPlayAnimInstructionClicked",
    "onPlayVFXInstructionClicked"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CanvasWidget[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   80,    2, 0x0a,    1 /* Public */,
       3,    0,   81,    2, 0x0a,    2 /* Public */,
       4,    0,   82,    2, 0x0a,    3 /* Public */,
       5,    0,   83,    2, 0x0a,    4 /* Public */,
       6,    0,   84,    2, 0x0a,    5 /* Public */,
       7,    0,   85,    2, 0x0a,    6 /* Public */,
       8,    0,   86,    2, 0x0a,    7 /* Public */,
       9,    0,   87,    2, 0x0a,    8 /* Public */,
      10,    0,   88,    2, 0x0a,    9 /* Public */,
      11,    0,   89,    2, 0x0a,   10 /* Public */,
      12,    0,   90,    2, 0x0a,   11 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject CanvasWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CanvasWidget.offsetsAndSizes,
    qt_meta_data_CanvasWidget,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CanvasWidget_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<CanvasWidget, std::true_type>,
        // method 'onGetHealthInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSetHealthInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onGetWisdomInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSetWisdomInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSetLiteralInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onAddInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSubtractInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onMultiplyInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onDivideInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onPlayAnimInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onPlayVFXInstructionClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void CanvasWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CanvasWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onGetHealthInstructionClicked(); break;
        case 1: _t->onSetHealthInstructionClicked(); break;
        case 2: _t->onGetWisdomInstructionClicked(); break;
        case 3: _t->onSetWisdomInstructionClicked(); break;
        case 4: _t->onSetLiteralInstructionClicked(); break;
        case 5: _t->onAddInstructionClicked(); break;
        case 6: _t->onSubtractInstructionClicked(); break;
        case 7: _t->onMultiplyInstructionClicked(); break;
        case 8: _t->onDivideInstructionClicked(); break;
        case 9: _t->onPlayAnimInstructionClicked(); break;
        case 10: _t->onPlayVFXInstructionClicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *CanvasWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CanvasWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CanvasWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int CanvasWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
